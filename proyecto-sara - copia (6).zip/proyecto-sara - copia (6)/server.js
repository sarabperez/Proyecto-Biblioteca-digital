const express = require('express');
const app = express();
const cors = require('cors');
const routes = require('./servidor/rutas/all.routes');
const { configureDB } = require('./servidor/configuracion/config.mongoose');


app.use(cors({
    origin: 'http://localhost:3000'
}));

const PORT = process.env.PORT || 9000;

configureDB();


app.use(express.json());


app.use('/mi-biblioteca-digital', routes);


app.listen(PORT, () => {
    console.log(`Servidor en ejecución en el puerto ${PORT}`);
});
