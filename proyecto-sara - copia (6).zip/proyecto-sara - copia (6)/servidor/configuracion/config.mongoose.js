const mongoose = require('mongoose');
module.exports = {
    configureDB: () => {
        mongoose.connect('mongodb://localhost/bibliDigital_db', {
            serverSelectionTimeoutMS: 30000,
        })
            .then(() => console.log("Conexion establecida con la base de datos"))
            .catch(err => console.log("Something went wrong", err))
    }
}