const express = require('express');
const router = express.Router();
const controladorGeneral = require('../controladores/models.controllers');
const { Movie, Book, Series, Anime } = require('../modelos/movie.model');
const movieController = require('../controladores/movie.controller');
const bookController = require('../controladores/book.controller');
const seriesController = require('../controladores/series.controller');
const animeController = require('../controladores/anime.controller');


router.get('/all', async (req, res) => {
    try {
        const [movies, books, series, anime] = await Promise.all([
            controladorGeneral.getAllElements(req, Movie),
            controladorGeneral.getAllElements(req, Book),
            controladorGeneral.getAllElements(req, Series),
            controladorGeneral.getAllElements(req, Anime)
        ]);

        res.status(200).json({
            movies,
            books,
            series,
            anime
        });
    } catch (error) {
        console.error('Error al obtener todos los elementos:', error);
        res.status(500).json({ error: 'Error al obtener todos los elementos' });
    }
});




router.post('/movie/new', movieController.createNewMovie);
router.get('/movie', movieController.getAllMovie);
router.get('/movie/:id', movieController.getMovieById);
router.put('/movie/:id', movieController.updateMovieById);
router.delete('/movie/:id', movieController.deleteMovieById);


router.post('/book/new', bookController.createNewBook);
router.get('/book', bookController.getAllBook);
router.get('/book/:id', bookController.getBookById);
router.put('/book/:id', bookController.updateBookById);
router.delete('/book/:id', bookController.deleteBookById);


router.post('/series/new', seriesController.createNewSeries);
router.get('/series', seriesController.getAllSeries);
router.get('/series/:id', seriesController.getSeriesById);
router.put('/series/:id', seriesController.updateSeriesById);
router.delete('/series/:id', seriesController.deleteSeriesById);


router.post('/anime/new', animeController.createNewAnime);
router.get('/anime', animeController.getAllAnime);
router.get('/anime/:id', animeController.getAnimeById);
router.put('/anime/:id', animeController.updateAnimeById);
router.delete('/anime/:id', animeController.deleteAnimeById);


module.exports = router;
