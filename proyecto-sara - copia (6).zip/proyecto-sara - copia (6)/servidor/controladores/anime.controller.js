const Modelos = require('../modelos/movie.model');
const controladorGeneral = require('./models.controllers');

const createNewAnime = (req, res) => controladorGeneral.createNewElement(req, res, Modelos.Anime);
const getAllAnime = (req, res) => controladorGeneral.getAllElements(req, res, Modelos.Anime);
const getAnimeById = (req, res) => controladorGeneral.getElementById(req, res, Modelos.Anime);
const updateAnimeById = (req, res) => controladorGeneral.updateElementById(req, res, Modelos.Anime);
const deleteAnimeById = (req, res) => controladorGeneral.deleteElementById(req, res, Modelos.Anime);

module.exports = {
    createNewAnime,
    getAllAnime,
    getAnimeById,
    updateAnimeById,
    deleteAnimeById
};
