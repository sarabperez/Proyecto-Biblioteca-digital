const createNewElement = (req, res, Model) => {
    const { score } = req.body;

    if (score < 1 || score > 5) {
        return res.status(400).json({ error: 'El score debe estar entre 1 y 5' });
    }
    const { yearStarted } = req.body;
    if (yearStarted < 2002 || yearStarted > 2024) {
        return res.status(400).json({ error: 'El año de inicio debe estar entre 2002 y el año actual' });
    }


    const { status } = req.body;
    if (status !== "Iniciado" && status !== "Concluido") {
        return res.status(400).json({ error: 'No agregó un valor válido para status' });
    }

    const newElement = new Model(req.body);
    newElement.save()
        .then(element => res.status(201).json(element))
        .catch(err => res.status(400).json(err));
}

const getAllElements = async (req, Model) => {
    return await Model.find();
}

const getElementById = (req, res, Model) => {
    const { id } = req.params;

    Model.findById(id)
        .then(element => {
            if (!element) {
                return res.status(404).json({ error: 'Elemento no encontrado' });
            }
            res.status(200).json(element);
        })
        .catch(err => res.status(500).json(err));
};

const updateElementById = (req, res, Model) => {
    const { id } = req.params;
    const updates = req.body;
    Model.findByIdAndUpdate(id, updates, { new: true })
        .then(updatedElement => {
            if (!updatedElement) {
                return res.status(400).json({ message: "Elemento no encontrado" })
            }
            res.status(200).json(updatedElement);
        })
        .catch(err => res.status(400).json(err));
}

const deleteElementById = (req, res, Model) => {
    const { id } = req.params;
    Model.findByIdAndDelete(id)
        .then(deletedElement => {
            if (!deletedElement) {
                return res.status(404).json({ message: 'Elemento no encontrado' });
            }
            res.status(200).json({ message: 'Elemento eliminado', element: deletedElement });
        })
        .catch(err => res.status(500).json(err));
}

const getAllElementsFromAllModels = async (req, res, models) => {
    try {
        let allElements = {};

        for (const model of models) {
            const elements = await model.find();
            const modelName = model.modelName || model.toLowerCase();
            allElements[modelName] = elements;
        }

        res.status(200).json(allElements);
    } catch (error) {
        console.error('Error al obtener todos los elementos:', error);
        res.status(500).json({ error: 'Error al obtener todos los elementos' });
    }
}


module.exports = {
    createNewElement,
    getAllElements,
    getElementById,
    updateElementById,
    deleteElementById,
    getAllElementsFromAllModels
};
