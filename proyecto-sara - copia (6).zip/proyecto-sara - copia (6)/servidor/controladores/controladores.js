const movieController = require('./movie.controller');
const bookController = require('./book.controller');
const seriesController = require('./series.controller');
const animeController = require('./anime.controller');

module.exports = {
    movieController,
    bookController,
    seriesController,
    animeController
};
