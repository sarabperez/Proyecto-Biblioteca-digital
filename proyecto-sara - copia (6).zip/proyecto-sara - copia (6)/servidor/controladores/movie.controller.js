const Modelos = require('../modelos/movie.model');
const controladorGeneral = require('./models.controllers');


const createNewMovie = (req, res) => controladorGeneral.createNewElement(req, res, Modelos.Movie);
const getAllMovie = (req, res) => controladorGeneral.getAllElements(req, res, Modelos.Movie);
const getMovieById = (req, res) => controladorGeneral.getElementById(req, res, Modelos.Movie);
const updateMovieById = (req, res) => controladorGeneral.updateElementById(req, res, Modelos.Movie);
const deleteMovieById = (req, res) => controladorGeneral.deleteElementById(req, res, Modelos.Movie);

module.exports = {
    createNewMovie,
    getAllMovie,
    getMovieById,
    updateMovieById,
    deleteMovieById
};
