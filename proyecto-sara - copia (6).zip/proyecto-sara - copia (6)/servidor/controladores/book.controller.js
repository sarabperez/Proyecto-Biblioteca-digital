const Modelos = require('../modelos/movie.model'); // Importa todos los modelos
const controladorGeneral = require('./models.controllers'); // Importar el controlador general

// Funciones específicas para libros
const createNewBook = (req, res) => controladorGeneral.createNewElement(req, res, Modelos.Book);
const getAllBook = (req, res) => controladorGeneral.getAllElements(req, res, Modelos.Book);
const getBookById = (req, res) => controladorGeneral.getElementById(req, res, Modelos.Book);
const updateBookById = (req, res) => controladorGeneral.updateElementById(req, res, Modelos.Book);
const deleteBookById = (req, res) => controladorGeneral.deleteElementById(req, res, Modelos.Book);

module.exports = {
    createNewBook,
    getAllBook,
    getBookById,
    updateBookById,
    deleteBookById
};
