const Modelos = require('../modelos/movie.model');
const controladorGeneral = require('./models.controllers');

// Funciones específicas para series
const createNewSeries = (req, res) => controladorGeneral.createNewElement(req, res, Modelos.Series);
const getAllSeries = (req, res) => controladorGeneral.getAllElements(req, res, Modelos.Series);
const getSeriesById = (req, res) => controladorGeneral.getElementById(req, res, Modelos.Series);
const updateSeriesById = (req, res) => controladorGeneral.updateElementById(req, res, Modelos.Series);
const deleteSeriesById = (req, res) => controladorGeneral.deleteElementById(req, res, Modelos.Series);

module.exports = {
    createNewSeries,
    getAllSeries,
    getSeriesById,
    updateSeriesById,
    deleteSeriesById
};
