const mongoose = require("mongoose");



const MovieSchema = new mongoose.Schema({

    title: {
        type: String,
        required: [true, "Debe ingresar el nombre de la pelicula"]
    },
    genre: {
        type: String,
        required: [true, "Debe ingresar el genero de la pelicula"]
    },
    protagonistas: {
        type: String,
        required: false
    },
    status: {
        type: String,
        enum: ['Iniciado', 'Concluido'],
        default: 'Iniciado',
        required: [true, "Debe ingresar el estado de la pelicula"]
    },
    score: {
        type: Number,
        min: 0,
        max: 5,
        required: true
    },
    yearStarted: {
        type: Number,
        min: 2002,
        max: 2024,
        required: [true, "Debe ingresar el año en que inicio"]
    },
    comment: {
        type: String,
        required: [true, "Debe ingresar un comentario"]
    }

})
const Movie = mongoose.model('Movie', MovieSchema);





const BookSchema = new mongoose.Schema({

    title: {
        type: String,
        required: [true, "Debe ingresar el título del libro"]
    },
    author: {
        type: String,
        required: [true, "Debe ingresar el autor del libro"]
    },
    genre: {
        type: String,
        required: [true, "Debe ingresar el género del libro"]
    },
    status: {
        type: String,
        enum: ['Iniciado', 'Concluido'],
        default: 'Iniciado',
        required: [true, "Debe ingresar el estado del libro"]
    },
    score: {
        type: Number,
        min: 0,
        max: 5,
        require: true
    },
    yearStarted: {
        type: Number,
        min: 2002,
        max: 2024,
        required: [true, "Debe ingresar el año en que inicio"]
    },
    comment: {
        type: String,
        required: [true, "Debe ingresar un comentario"]
    },
    img: {
        type: String,
        required: false
    }
});
const Book = mongoose.model('Book', BookSchema);





const SeriesSchema = new mongoose.Schema({

    title: {
        type: String,
        required: [true, "Debe ingresar el título de la serie"]
    },
    genre: {
        type: String,
        required: [true, "Debe ingresar el género de la serie"]
    },
    season: {
        type: Number,
        required: [true, "Debe ingresar el número de la temporada"]
    },
    protagonistas: {
        type: String,
        required: [true, "Debe ingresar los nombres de los protagonistas"]
    },
    personajesfavs: {
        type: String,
        required: [true, "Debe ingresar los nombres de los personajes favoritos"]
    },
    status: {
        type: String,
        enum: ['Iniciado', 'Concluido'],
        default: 'Iniciado',
        required: [true, "Debe ingresar el estado de la serie"]
    },
    score: {
        type: Number,
        min: 0,
        max: 5,
        required: true
    },
    yearStarted: {
        type: Number,
        min: 2002,
        max: 2024,
        required: [true, "Debe ingresar el año en que inicio"]
    },
    comment: {
        type: String,
        required: [true, "Debe ingresar un comentario"]
    },
    img: {
        type: String,
        required: false
    }
});

const Series = mongoose.model('Series', SeriesSchema);





const AnimeSchema = new mongoose.Schema({

    title: {
        type: String,
        required: [true, "Debe ingresar el título del anime"]
    },
    genre: {
        type: String,
        required: [true, "Debe ingresar el género del anime"]
    },
    protagonistas: {
        type: String,
        require: [true, "Debe ingresar los nombres de los protagonistas"]
    },
    season: {
        type: Number,
        required: [true, "Debe ingresar el número de la temporada"]
    },
    personajesfavs: {
        type: String,
        require: [true, "Debe ingresar los nombres de los personajes favoritos"]
    },
    status: {
        type: String,
        enum: ['Iniciado', 'Concluido'],
        default: 'Iniciado',
        required: [true, "Debe ingresar el estado del anime"]
    },
    comment: {
        type: String,
        required: [true, "Debe ingresar un comentario"]
    },
    score: {
        type: Number,
        min: 0,
        max: 5,
        required: true
    },
    yearStarted: {
        type: Number,
        min: 2002,
        max: 2024,
        required: [true, "Debe ingresar el año en que inicio"]
    },
    img: {
        type: String,
        required: false
    }
});
const Anime = mongoose.model('Anime', AnimeSchema);


module.exports = {
    Movie,
    Book,
    Series,
    Anime
};

