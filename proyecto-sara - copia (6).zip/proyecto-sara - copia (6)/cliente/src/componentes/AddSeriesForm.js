import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import "./FormStyle.css"

const AddSeriesForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        title: '',
        genre: '',
        season: 1,
        protagonistas: '',
        personajesfavs: '',
        status: 'Iniciado',
        score: 0,
        yearStarted: '',
        comment: '',
        type: 'series'
    });
    const [errorMessage, setErrorMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://localhost:9000/mi-biblioteca-digital/series/new', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                navigate('/');
            } else {
                throw new Error('Error al agregar la serie');
            }
        } catch (error) {
            console.error('Error al agregar la serie:', error.message);
            setErrorMessage('Error al agregar la serie');
        }
    };

    return (
        <div className="form-container">
            <form onSubmit={handleSubmit}>
                <input type="text" name="title" value={formData.title} onChange={handleChange} placeholder="Título" required />
                <input type="text" name="genre" value={formData.genre} onChange={handleChange} placeholder="Género" required />
                <input type="number" name="season" value={formData.season} onChange={handleChange} placeholder="Temporada" required />
                <input type="text" name="protagonistas" value={formData.protagonistas} onChange={handleChange} placeholder="Protagonistas" required />
                <input type="text" name="personajesfavs" value={formData.personajesfavs} onChange={handleChange} placeholder="Personajes Favoritos" required />
                <select name="status" value={formData.status} onChange={handleChange}>
                    <option value="Iniciado">Iniciado</option>
                    <option value="Concluido">Concluido</option>
                </select>
                <input type="number" name="score" value={formData.score} onChange={handleChange} placeholder="Puntuación" required />
                <input type="number" name="yearStarted" value={formData.yearStarted} onChange={handleChange} placeholder="Año de inicio" required />
                <input type="text" name="comment" value={formData.comment} onChange={handleChange} placeholder="Comentario" required />
                <button type="submit">Agregar Serie</button>
            </form>
            {errorMessage && <div className="error-message">{errorMessage}</div>}
        </div>
    );
};

export default AddSeriesForm;
