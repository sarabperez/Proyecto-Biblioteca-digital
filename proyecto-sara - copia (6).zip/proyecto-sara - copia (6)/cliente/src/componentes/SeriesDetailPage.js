import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const SeriesDetailPage = () => {
    const { id } = useParams();
    const [series, setSerie] = useState(null);
    const [editSerie, setEditSerie] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchSerie = async () => {
            try {
                const response = await axios.get(`http://localhost:9000/mi-biblioteca-digital/series/${id}`);
                const serieData = response.data;
                setSerie(serieData);
                setEditSerie(serieData);
            } catch (error) {
                console.error('Error al obtener la serie:', error);

                if (error.response && error.response.status === 404) {
                    setSerie(null);
                    setEditSerie(null);
                }
            }
        };

        fetchSerie();
    }, [id]);



    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditSerie({ ...editSerie, [name]: value });
    };

    const updateSerie = async () => {
        try {
            if (editSerie) {
                const response = await axios.put(`http://localhost:9000/mi-biblioteca-digital/series/${id}`, editSerie);
                if (response.status === 200) {
                    navigate('/');
                } else {
                    const responseBody = response.data;
                    alert(responseBody.errors.join('\n'));
                }
            } else {
                alert('No se ha proporcionado información de la serie para actualizar.');
            }
        } catch (error) {
            console.error('Error al actualizar la serie:', error);
            if (error.response && error.response.status === 400) {
                alert('Los datos proporcionados son incorrectos. Por favor, verifica los campos y vuelve a intentarlo.');
            } else {
                alert('Se produjo un error al intentar actualizar la serie. Por favor, inténtalo de nuevo más tarde.');
            }
        }
    };
    const deleteSerie = async () => {
        try {
            const response = await axios.delete(`http://localhost:9000/mi-biblioteca-digital/series/${id}`);
            if (response.status === 200) {
                navigate('/');
            } else {
                const responseBody = response.data;
                alert(responseBody.error);
            }
        } catch (error) {
            console.error('Error al eliminar la serie:', error);
            alert('Se produjo un error');
        }
    };


    const renderSerieDetails = () => {
        if (!series) {
            return <p>Cargando...</p>;
        }

        return (
            <div>
                <p>Titulo: <input type='text' name='title' value={editSerie.title} onChange={handleInputChange} /></p>
                <p>Año de Inicio: <input type="text" name="yearStarted" value={editSerie.yearStarted} onChange={handleInputChange} /></p>
                <p>Género: <input type="text" name="genre" value={editSerie.genre} onChange={handleInputChange} /></p>
                <p>Protagonistas: <input type="text" name="protagonistas" value={editSerie.protagonistas} onChange={handleInputChange} /></p>
                <p>Personajes favoritos: <input type='text' name='personajesfavs' value={editSerie.personajesfavs} onChange={handleInputChange} /></p>
                <p>Temporada: <input type='text' name='season' value={editSerie.season} onChange={handleInputChange} /></p>
                <p>Estado: <input type="text" name="status" value={editSerie.status} onChange={handleInputChange} /></p>
                <p>Puntuación: <input type="text" name="score" value={editSerie.score} onChange={handleInputChange} /></p>
                <p>Comentario: <input type="text" name="comment" value={editSerie.comment} onChange={handleInputChange} /></p>
                <button onClick={updateSerie}>Actualizar Serie</button>
                <button onClick={deleteSerie}>Eliminar Serie</button>
            </div>
        );
    };

    return (
        <div>
            <h2>Detalles de la Serie</h2>
            {renderSerieDetails()}
        </div>
    );
};

export default SeriesDetailPage;
