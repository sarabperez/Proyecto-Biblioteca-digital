import React, { useState, useEffect } from 'react';
import axios from 'axios';

const FinishedPage = () => {
    const [finishedElements, setFinishedElements] = useState([]);

    useEffect(() => {
        const fetchFinishedElements = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                const allElements = response.data;
                const finished = [];
                for (const category in allElements) {
                    const elements = allElements[category];
                    const filteredElements = elements.filter(element => element.status === "Concluido");
                    finished.push(...filteredElements);
                }
                setFinishedElements(finished);
            } catch (error) {
                console.error('Error al obtener los elementos finalizados:', error);
            }
        };

        fetchFinishedElements();
    }, []);

    return (
        <div>
            <h2>Finalizados</h2>
            <div>
                {finishedElements.map(element => (
                    <div key={element._id}>
                        <h3>{element.title}</h3>
                        <p>Estado: {element.status}</p>
                        <hr />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default FinishedPage;
