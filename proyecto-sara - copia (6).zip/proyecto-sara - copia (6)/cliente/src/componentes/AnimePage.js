import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./MainPage.style.css";


const AnimePage = () => {
    const [animes, setAnimes] = useState([]);

    useEffect(() => {
        const fetchAnimes = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                const allElements = response.data;

                if (Array.isArray(allElements.anime)) {
                    setAnimes(allElements.anime);
                } else {
                    console.error('El array de anime está vacío o no está definido');
                }
            } catch (error) {
                console.error('Error al obtener los animes:', error);
            }
        };

        fetchAnimes();
    }, []);
    const getRandomColor = () => {
        const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#9e9e9e', '#607d8b'];
        return colors[Math.floor(Math.random() * colors.length)];
    };
    return (
        <div className='title-h1'>
            <h1>Animes</h1>
            <div className='main-container'>
                <div className="content">
                    {animes.map(anime => (
                        <div key={anime._id} className="element" style={{ backgroundColor: getRandomColor() }}>
                            <h3>{anime.title}</h3>
                            <p>Año: {anime.yearStarted}</p>
                            <p>Género: {anime.genre}</p>
                            <Link to={`/anime/${anime._id}`}>Detalles</Link>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
};

export default AnimePage;
