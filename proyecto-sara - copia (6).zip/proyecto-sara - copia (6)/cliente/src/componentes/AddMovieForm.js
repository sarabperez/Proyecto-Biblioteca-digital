import React, { useState } from "react";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "./FormStyle.css";

const AddMovieForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        title: '',
        genre: '',
        protagonistas: '',
        status: 'Iniciado',
        score: 0,
        yearStarted: '',
        comment: '',
        type: 'movie'
    });
    const [errorMessage, setErrorMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:9000/mi-biblioteca-digital/movie/new', formData, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            navigate('/');

        } catch (error) {
            console.error('Error al agregar la película:', error.message);
            setErrorMessage('Error al agregar la película');
        }
    };


    return (
        <div className="form-container">
            <form onSubmit={handleSubmit}>
                <label>Título:</label>
                <input type="text" name="title" value={formData.title} onChange={handleChange} placeholder="Título" required />
                <label>Género:</label>
                <input type="text" name="genre" value={formData.genre} onChange={handleChange} placeholder="Género" required />
                <label>Protagonistas:</label>
                <input type="text" name="protagonistas" value={formData.protagonistas} onChange={handleChange} placeholder="Protagonistas" />
                <label>Estado:</label>
                <select name="status" value={formData.status} onChange={handleChange}>
                    <option value="Iniciado">Iniciado</option>
                    <option value="Concluido">Concluido</option>
                </select>
                <label>Puntuación:</label>
                <input type="number" name="score" value={formData.score} onChange={handleChange} placeholder="Puntuación" required />
                <label>Año de inicio:</label>
                <input type="number" name="yearStarted" value={formData.yearStarted} onChange={handleChange} placeholder="Año de inicio" required />
                <label>Comentario:</label>
                <input type="text" name="comment" value={formData.comment} onChange={handleChange} placeholder="Comentario" required />
                <button type="submit">Agregar Película</button>
            </form>
            {errorMessage && <div className="error-message">{errorMessage}</div>}
        </div>
    );
};

export default AddMovieForm;
