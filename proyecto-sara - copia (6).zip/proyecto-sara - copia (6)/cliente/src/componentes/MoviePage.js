import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./MainPage.style.css";


const MoviesPage = () => {
    const [movies, setMovies] = useState([]);

    useEffect(() => {
        const fetchMovies = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                const allElements = response.data;

                if (Array.isArray(allElements.movies)) {
                    setMovies(allElements.movies);
                } else {
                    console.error('El array de películas está vacío o no está definido');
                }
            } catch (error) {
                console.error('Error al obtener las películas:', error);
            }
        };

        fetchMovies();
    }, []);
    const getRandomColor = () => {
        const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#9e9e9e', '#607d8b'];
        return colors[Math.floor(Math.random() * colors.length)];
    };
    return (
        <div className='title-h1'>
            <h1>Películas</h1>
            <div className='main-container'>
                <div className="content">
                    {movies.map(movie => (
                        <div key={movie._id} className="element" style={{ backgroundColor: getRandomColor() }}>
                            <h3>{movie.title}</h3>
                            <p>Año: {movie.yearStarted}</p>
                            <p>Género: {movie.genre}</p>
                            <Link to={`/movie/${movie._id}`}>Detalles</Link>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
};

export default MoviesPage;
