import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const AnimeDetailPage = () => {
    const { id } = useParams();
    const [anime, setAnime] = useState(null);
    const [editAnime, setEditAnime] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchAnime = async () => {
            try {
                const response = await axios.get(`http://localhost:9000/mi-biblioteca-digital/anime/${id}`);
                const animeData = response.data;
                setAnime(animeData);
                setEditAnime(animeData);
            } catch (error) {
                console.error('Error al obtener el anime:', error);
                if (error.response && error.response.status === 404) {
                    setAnime(null);
                    setEditAnime(null);
                }
            }
        };

        fetchAnime();
    }, [id]);



    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditAnime({ ...editAnime, [name]: value });
    };

    const updateAnime = async () => {
        try {
            if (editAnime) {
                await axios.put(`http://localhost:9000/mi-biblioteca-digital/anime/${id}`, editAnime);
                navigate('/');
            }
        } catch (error) {
            console.error('Error al actualizar el anime:', error);
        }
    };
    const deleteAnime = async () => {
        try {
            const response = await axios.delete(`http://localhost:9000/mi-biblioteca-digital/anime/${id}`);
            if (response.status === 200) {
                navigate('/');
            } else {
                const responseBody = response.data;
                alert(responseBody.error);
            }
        } catch (error) {
            console.error('Error al eliminar el anime:', error);
            alert('Se produjo un error al intentar eliminar el anime. Por favor, inténtalo de nuevo más tarde.');
        }
    };

    const renderAnimeDetails = () => {
        if (!anime) {
            return <p>Cargando...</p>;
        }

        return (
            <div>
                <p>Titulo: <input type='text' name='title' value={editAnime.title} onChange={handleInputChange} /></p>
                <p>Año de Inicio: <input type="text" name="yearStarted" value={editAnime.yearStarted} onChange={handleInputChange} /></p>
                <p>Género: <input type="text" name="genre" value={editAnime.genre} onChange={handleInputChange} /></p>
                <p>Protagonistas: <input type="text" name="protagonistas" value={editAnime.protagonistas} onChange={handleInputChange} /></p>
                <p>Personajes favoritos: <input type='text' name='personajesfavs' value={editAnime.personajesfavs} onChange={handleInputChange} /></p>
                <p>Temporada: <input type='text' name='season' value={editAnime.season} onChange={handleInputChange} /></p>
                <p>Estado: <input type="text" name="status" value={editAnime.status} onChange={handleInputChange} /></p>
                <p>Puntuación: <input type="text" name="score" value={editAnime.score} onChange={handleInputChange} /></p>
                <p>Comentario: <input type="text" name="comment" value={editAnime.comment} onChange={handleInputChange} /></p>
                <button onClick={updateAnime}>Actualizar Anime</button>
                <button onClick={deleteAnime}>Eliminar Serie</button>

            </div>
        );
    };

    return (
        <div>
            <h2>Detalles del anime</h2>
            {renderAnimeDetails()}
        </div>
    );
};

export default AnimeDetailPage;
