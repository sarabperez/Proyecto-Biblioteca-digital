import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const BookDetailPage = () => {
    const { id } = useParams();
    const [book, setBook] = useState(null);
    const [editBook, setEditBook] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchBook = async () => {
            try {
                const response = await axios.get(`http://localhost:9000/mi-biblioteca-digital/book/${id}`);
                const bookData = response.data;
                setBook(bookData);
                setEditBook(bookData);
            } catch (error) {
                console.error('Error al obtener el libro:', error);

                if (error.response && error.response.status === 404) {
                    setBook(null);
                    setEditBook(null);
                }
            }
        };

        fetchBook();
    }, [id]);



    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditBook({ ...editBook, [name]: value });
    };

    const updateBook = async () => {
        try {
            if (editBook) {
                await axios.put(`http://localhost:9000/mi-biblioteca-digital/book/${id}`, editBook);
                navigate('/');
            }
        } catch (error) {
            console.error('Error al actualizar el libro:', error);
        }
    };

    const deleteBook = async () => {
        try {
            const response = await axios.delete(`http://localhost:9000/mi-biblioteca-digital/book/${id}`);
            if (response.status === 200) {
                navigate('/');
            } else {
                const responseBody = response.data;
                alert(responseBody.error);
            }
        } catch (error) {
            console.error('Error al eliminar el libro:', error);
            alert('Se produjo un error al intentar eliminar el libro. Por favor, inténtalo de nuevo más tarde.');
        }
    };


    const renderBookDetails = () => {
        if (!book) {
            return <p>Cargando...</p>;
        }

        return (
            <div>
                <p>Titulo: <input type='text' name='title' value={editBook.title} onChange={handleInputChange} /></p>
                <p>Año de Inicio: <input type="text" name="yearStarted" value={editBook.yearStarted} onChange={handleInputChange} /></p>
                <p> Autor:<input type='text' name='author' value={editBook.author} onChange={handleInputChange} /></p>
                <p>Género: <input type="text" name="genre" value={editBook.genre} onChange={handleInputChange} /></p>
                <p>Estado: <input type="text" name="status" value={editBook.status} onChange={handleInputChange} /></p>
                <p>Puntuación: <input type="text" name="score" value={editBook.score} onChange={handleInputChange} /></p>
                <p>Comentario: <input type="text" name="comment" value={editBook.comment} onChange={handleInputChange} /></p>
                <button onClick={updateBook}>Actualizar libro</button>
                <button onClick={deleteBook}>Eliminar libro</button>

            </div>
        );
    };

    return (
        <div>
            <h2>Detalles del libro</h2>
            {renderBookDetails()}
        </div>
    );
};

export default BookDetailPage;
