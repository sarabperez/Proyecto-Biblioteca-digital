import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BestRatedPage = () => {
    const [bestRatedElements, setBestRatedElements] = useState([]);

    useEffect(() => {
        const fetchBestRatedElements = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                const allElements = response.data;

                const bestRated = [];
                for (const category in allElements) {
                    const elements = allElements[category];
                    const filteredElements = elements.filter(element => element.score >= 4 && element.score <= 5);
                    bestRated.push(...filteredElements);
                }
                setBestRatedElements(bestRated);
            } catch (error) {
                console.error('Error al obtener los elementos mejor valorados:', error);
            }
        };

        fetchBestRatedElements();
    }, []);


    return (
        <div>
            <h2>Mejor Valorados</h2>
            <div>
                {bestRatedElements.map(element => (
                    <div key={element._id}>
                        <h3>{element.title}</h3>
                        <p>Puntuación: {element.score}</p>

                        <hr />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BestRatedPage;
