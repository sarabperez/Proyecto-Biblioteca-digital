import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./MainPage.style.css";

const MainPage = () => {
    const [elements, setElements] = useState([]);

    useEffect(() => {
        const fetchElements = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                console.log(response);
                if (Array.isArray(response.data.movies) && Array.isArray(response.data.books) && Array.isArray(response.data.series) && Array.isArray(response.data.anime)) {
                    const allElements = [...response.data.movies, ...response.data.books, ...response.data.series, ...response.data.anime];
                    const sortedElements = allElements.sort((a, b) => b.yearStarted - a.yearStarted);
                    setElements(sortedElements);
                } else {
                    console.error('La respuesta del servidor no contiene las propiedades esperadas o no son arrays.');
                }
            } catch (error) {
                console.error('Error al obtener elementos:', error);
            }
        };
        fetchElements();
    }, []);


    const getRandomColor = () => {
        const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#9e9e9e', '#607d8b'];
        return colors[Math.floor(Math.random() * colors.length)];
    };

    return (
        <div>
            <div className='title-h1'>
                <h1>Mi biblioteca digital</h1>
            </div>
            <div className="submenu-1">
                <Link to="/peliculas">Películas</Link>
                <Link to="/series">Series</Link>
                <Link to="/anime">Anime</Link>
                <Link to="/libros">Libros</Link>
            </div>
            <div className="main-container">
                <div className="sidebar">
                    <h2 className='menu'>Menú</h2>
                    <div>
                        <h2 className='submenu'>Agregar Nuevo Elemento</h2>
                        <p><Link to="/element/agregar-libro">Agregar Libro</Link></p>
                        <p><Link to="/element/agregar-pelicula">Agregar Película</Link></p>
                        <p><Link to="/element/agregar-serie">Agregar Serie</Link></p>
                        <p><Link to="/element/agregar-anime">Agregar Anime</Link></p>
                    </div>
                    <div>
                        <h3>Ver:</h3>
                        <Link to="/all">Mejor Puntuados</Link>
                        <div></div>
                        <Link to="/finalizados">Finalizados</Link>
                    </div>
                </div>
                <div className="content">
                    {elements.map((element, index) => (
                        <div key={index} className="element" style={{ backgroundColor: getRandomColor() }}>
                            <h3>{element.title}</h3>
                            <p>{element.yearStarted}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div >
    );
};

export default MainPage;
