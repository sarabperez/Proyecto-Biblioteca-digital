import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./MainPage.style.css";


const BookPage = () => {
    const [books, setBooks] = useState([]);

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                const allElements = response.data;

                if (Array.isArray(allElements.books)) {
                    setBooks(allElements.books);
                } else {
                    console.error('El array de libros está vacío o no está definido');
                }
            } catch (error) {
                console.error('Error al obtener los libros:', error);
            }
        };

        fetchBooks();
    }, []);
    const getRandomColor = () => {
        const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#9e9e9e', '#607d8b'];
        return colors[Math.floor(Math.random() * colors.length)];
    };
    return (
        <div className='title-h1'>
            <h1>Libros</h1>
            <div className='main-container'>
                <div className="content">
                    {books.map(books => (
                        <div key={books._id} className="element" style={{ backgroundColor: getRandomColor() }}>
                            <h3>{books.title}</h3>
                            <p>Autor: {books.author}</p>
                            <p>Genero: {books.genre}</p>
                            <Link to={`/libros/${books._id}`}>Detalles</Link>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
};

export default BookPage;
