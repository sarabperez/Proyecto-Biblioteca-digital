import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./MainPage.style.css";


const SeriesPage = () => {
    const [series, setSeries] = useState([]);

    useEffect(() => {
        const fetchSeries = async () => {
            try {
                const response = await axios.get('http://localhost:9000/mi-biblioteca-digital/all');
                const allElements = response.data;

                if (Array.isArray(allElements.series)) {
                    setSeries(allElements.series);
                } else {
                    console.error('El array de series está vacío o no está definido');
                }
            } catch (error) {
                console.error('Error al obtener las series:', error);
            }
        };

        fetchSeries();
    }, []);
    const getRandomColor = () => {
        const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#9e9e9e', '#607d8b'];
        return colors[Math.floor(Math.random() * colors.length)];
    };
    return (
        <div className='title-h1'>
            <h1>Series</h1>
            <div className='main-container'>
                <div className="content">
                    {series.map(series => (
                        <div key={series._id} className="element" style={{ backgroundColor: getRandomColor() }}>
                            <h3>{series.title}</h3>
                            <p>Año: {series.yearStarted}</p>
                            <p>Género: {series.genre}</p>
                            <Link to={`/series/${series._id}`}>Detalles</Link>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
};

export default SeriesPage;
