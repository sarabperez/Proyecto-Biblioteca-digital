import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const MovieDetailPage = () => {
    const { id } = useParams();
    const [movie, setMovie] = useState(null);
    const [editMovie, setEditMovie] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchMovie = async () => {
            try {
                const response = await axios.get(`http://localhost:9000/mi-biblioteca-digital/movie/${id}`);
                const movieData = response.data;
                setMovie(movieData);
                setEditMovie(movieData);
            } catch (error) {
                console.error('Error al obtener la película:', error);
                if (error.response && error.response.status === 404) {
                    setMovie(null);
                    setEditMovie(null);
                }
            }
        };

        fetchMovie();
    }, [id]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditMovie({ ...editMovie, [name]: value });
    };

    const updateMovie = async () => {
        try {
            if (editMovie) {
                await axios.put(`http://localhost:9000/mi-biblioteca-digital/movie/${id}`, editMovie);
                navigate('/');
            }
        } catch (error) {
            console.error('Error al actualizar la película:', error);
        }
    };

    const deleteMovie = async () => {
        try {
            const response = await axios.delete(`http://localhost:9000/mi-biblioteca-digital/movie/${id}`);
            if (response.status === 200) {
                navigate('/');
            } else {
                const responseBody = response.data;
                alert(responseBody.error);
            }
        } catch (error) {
            console.error('Error al eliminar la pelicula:', error);
            alert('Se produjo un error al intentar eliminar la pelicula. Por favor, inténtalo de nuevo más tarde.');
        }
    };
    const renderMovieDetails = () => {
        if (!movie) {
            return <p>Cargando...</p>;
        }

        return (
            <div>
                <p>Titulo: <input type='text' name='title' value={editMovie.title} onChange={handleInputChange} /></p>
                <p>Año de Inicio: <input type="text" name="yearStarted" value={editMovie.yearStarted} onChange={handleInputChange} /></p>
                <p>Género: <input type="text" name="genre" value={editMovie.genre} onChange={handleInputChange} /></p>
                <p>Protagonistas: <input type="text" name="protagonistas" value={editMovie.protagonistas} onChange={handleInputChange} /></p>
                <p>Estado: <input type="text" name="status" value={editMovie.status} onChange={handleInputChange} /></p>
                <p>Puntuación: <input type="text" name="score" value={editMovie.score} onChange={handleInputChange} /></p>
                <p>Comentario: <input type="text" name="comment" value={editMovie.comment} onChange={handleInputChange} /></p>
                <button onClick={updateMovie}>Actualizar Película</button>
                <button onClick={deleteMovie}>Eliminar Pelicula</button>

            </div>
        );
    };

    return (
        <div>
            <h2>Detalles de la Película</h2>
            {renderMovieDetails()}
        </div>
    );
};

export default MovieDetailPage;
