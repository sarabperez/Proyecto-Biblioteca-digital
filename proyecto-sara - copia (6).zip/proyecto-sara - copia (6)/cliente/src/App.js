import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MainPage from './componentes/MainMainPage';
import BestRatedPage from './componentes/BestRatedPage';
import MovieDetailPage from './componentes/MovieDetailPage';
import AddBookForm from './componentes/AddBookForm';
import AddMovieForm from './componentes/AddMovieForm';
import AddSeriesForm from './componentes/AddSeriesForm';
import AddAnimeForm from './componentes/AddAnimeForm';
import FinishedPage from './componentes/FinishedPage';
import MoviePage from './componentes/MoviePage';
import SeriesPage from './componentes/SeriesPage';
import AnimePage from './componentes/AnimePage';
import BookPage from './componentes/BookPage';
import SeriesDetailPage from './componentes/SeriesDetailPage';
import AnimeDetailPage from './componentes/AnimeDetailPage';
import BookDetailPage from './componentes/BookDetailPage';

const App = () => {

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<MainPage />} />

          <Route path="/element/agregar-libro" element={<AddBookForm />} />
          <Route path="/element/agregar-pelicula" element={<AddMovieForm />} />
          <Route path="/element/agregar-serie" element={<AddSeriesForm />} />
          <Route path="/element/agregar-anime" element={<AddAnimeForm />} />

          <Route path="/peliculas" element={<MoviePage />} />
          <Route path="/series" element={<SeriesPage />} />
          <Route path="/anime" element={<AnimePage />} />
          <Route path="/libros" element={<BookPage />} />


          <Route path="/movie/:id" element={<MovieDetailPage />} />
          <Route path="/series/:id" element={<SeriesDetailPage />} />
          <Route path="/anime/:id" element={<AnimeDetailPage />} />
          <Route path="/libros/:id" element={<BookDetailPage />} />



          <Route path="/all" element={<BestRatedPage />} />
          <Route path="/finalizados" element={<FinishedPage />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;
